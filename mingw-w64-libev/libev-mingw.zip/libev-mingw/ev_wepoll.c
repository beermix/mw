/* Wrapper for wepoll.c */

#ifdef _WIN32
#include "wepoll.c"
#endif
